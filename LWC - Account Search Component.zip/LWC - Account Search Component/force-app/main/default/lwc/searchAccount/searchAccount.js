import { LightningElement, wire } from 'lwc';
import findAccounts from '@salesforce/apex/accountController.findAccounts';

const DELAY = 300;

export default class SearchAccount extends LightningElement {
    searchKey = '';
    selectedAccountId; // Stores the ID of the clicked account
    //using wire method with parameters
    @wire(findAccounts, { searchKey: '$searchKey' })
    accounts;

    handleKeyChange(event) {
        window.clearTimeout(this.delayTimeout);
        const searchKey = event.target.value;
        this.delayTimeout = setTimeout(() => {
            this.searchKey = searchKey;
        }, DELAY);
    }

    handleAccountClick(event) {
        // setting selected account's ID when an account is clicked
        this.selectedAccountId = event.currentTarget.dataset.id;
    }

    get hasAccounts() {
        //check if the search results contain any accounts
        //boolean 
        return this.accounts && this.accounts.data && this.accounts.data.length > 0;
    }
}
