// accountDetail.js
import { LightningElement, api } from 'lwc';

export default class AccountDetail extends LightningElement {
    //Makes accountId a public property 
    @api accountId;
}
