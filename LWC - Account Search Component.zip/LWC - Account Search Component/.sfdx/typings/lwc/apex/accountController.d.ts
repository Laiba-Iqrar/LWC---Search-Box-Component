declare module "@salesforce/apex/accountController.getAccountList" {
  export default function getAccountList(): Promise<any>;
}
declare module "@salesforce/apex/accountController.findAccounts" {
  export default function findAccounts(param: {searchKey: any}): Promise<any>;
}
